# coding=utf-8

from setuptools import setup

setup(
    name='delete_me',
    version='0.2a1',
    description="""Dummy artefact for devpi_cleaner tests.""",
    author='Blue Yonder Technology Foundation Team',
    url='http://jira.phi-tps.local',
    author_email='Blue-Yonder.TeamTechnologie@blue-yonder.com',
    packages=['delete_me'],
)
